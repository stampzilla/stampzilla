<?php

const critical = 0;
const error = 1;
const warning = 2;
const notice = 3;
const debug = 4;
const unknown = 5;

?>
