<div id="videoplayers">

</div>
<div id="movie_files" ontouchstart="touchStart(event,'movie_files');"  ontouchend="touchEnd(event);" ontouchmove="touchMove(event);" ontouchcancel="touchCancel(event);">

</div>
